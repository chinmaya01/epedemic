 <?php
$servername = "sql200.epizy.com";
$username = "epiz_24318821";
$password = "MlRpv9MjnyA";
$dbname = "epiz_24318821_hospital";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT lat,lon,disease,disease_count FROM location";
$result = $conn->query($sql);
$json = array();

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $disease_info = array(
        'latitude' => $row['lat'],
        'longitude' => $row['lon'],
        'disease_Name' => $row['disease'],
        'disease_Count' => $row['disease_count']
    );
    array_push($json, $disease_info);
}

echo(json_encode($json));
}
 else {
    echo "0 results";
}
$conn->close();
?> 