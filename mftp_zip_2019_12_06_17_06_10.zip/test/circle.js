ymaps.ready(init);
var data={};
function loadXMLDoc() {
    $.ajax({
        url: 'getvalues.php',
        type: 'POST',
        dataType: 'JSON', // added data type
        contentType: 'text/plain',
        async: false,
        success: function(jsonstring) {
            data = jsonstring;
        }
    });
}
loadXMLDoc();
console.log(data);
console.log(data.length);

function init() {
    // Creating the map.
    var myMap = new ymaps.Map("map", {
            center: [17.47, 78.72],
            zoom: 10
        }, {
            searchControlProvider: 'yandex#search'
        });
    // Creating a circle.
    for(var i=0;i<data.length;i++){
        var myCircle = new ymaps.Circle([
            // The coordinates of the center of the circle.
            // write ajax call to get values from server using php to connect db and fecth values
            [data[i]["latitude"], data[i]["longitude"]],
            // The radius of the circle in meters.
            500
        ], {
            /**
             * Describing the properties of the circle.
             * The contents of the balloon.
             */
            balloonContent: data[i]["disease_Name"].toUpperCase() + " is spreading",
            // The contents of the hint.
            hintContent: data[i]["disease_Name"].toUpperCase()+ " : " +data[i]["disease_Count"]
        }, {
            /**
             * Setting the circle options.
             * Enabling drag-n-drop for the circle.
             */
            
            /**
             * Fill color.
             * The last byte (77) defines transparency.
             * The transparency of the fill can also be set using the option "fillOpacity".
             */
            fillColor: "#e3725977",
            // Stroke color.
            strokeColor: "#ed5432",
            // Stroke transparency.
            strokeOpacity: 0,
            // The width of the stroke in pixels.
            strokeWidth: 2
        });

        // Adding the circle to the map.
        myMap.geoObjects.add(myCircle);
    }
}
