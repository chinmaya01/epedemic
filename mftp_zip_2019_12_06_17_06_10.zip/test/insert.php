

<?php
$na=$_POST['l'];
$em=$_POST['la'];
$pa=$_POST['d'];
$dc=$_POST['dc'];

$servername = "sql200.epizy.com";
$username = "epiz_24318821";
$password = "MlRpv9MjnyA";
$dbname = "epiz_24318821_hospital";
if($na&&$em){
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

//$sql = "INSERT INTO MyGuests (firstname, lastname, email)
//VALUES ('$name', 'ganji', 'ganji@example.com')";
 $sql = "INSERT INTO location(lat,lon,disease,disease_count)
VALUES ('$na', '$em', '$pa','$dc')";
if ($conn->query($sql) === TRUE) {
   // echo '<a href="http://epidemictracker.epizy.com/test/one.html">click me</a>';
    echo "hii";
    //print '<a href='http://epidemictracker.epizy.com/test/one.html'>click here</a>' ;
    //echo "hi";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


$sql = "SELECT * FROM location";
$result = $conn->query($sql);
if ($result->num_rows > 0) 

{
    // output data of each row
     while($row = $result->fetch_assoc()) {
    	
       

/*else{
           
        }

    	//print $a;*/

   
    }
} else {
    echo "0 results";
}
}
else{
die("please enter latitude and longitude");
}
$conn->close();
?>
